#!/usr/bin/env python3
"""
Demonstration script for the FASTA parser.
Creates sample data and demonstrates all features.
"""

from fasta_parser import FastaParser, FastaSequence
import random
import gzip


def generate_random_sequence(length: int) -> str:
    """Generate a random DNA sequence."""
    return ''.join(random.choices('ATGC', k=length))


def create_sample_fasta(filename: str, num_sequences: int = 100):
    """Create a sample FASTA file for demonstration."""
    with open(filename, 'w') as f:
        for i in range(num_sequences):
            # Vary sequence lengths
            if i < 10:
                length = random.randint(5000, 20000)  # Long sequences
            elif i < 30:
                length = random.randint(1000, 5000)   # Medium sequences
            else:
                length = random.randint(100, 1000)    # Short sequences
            
            seq = generate_random_sequence(length)
            
            # Create varied headers
            if i % 3 == 0:
                header = f"chromosome_{i+1} Homo sapiens chromosome {i+1}"
            elif i % 3 == 1:
                header = f"contig_{i+1} length={length} GC={random.randint(40,60)}"
            else:
                header = f"gene_{i+1} protein_coding"
            
            f.write(f">{header}\n")
            
            # Write sequence with line wrapping
            for j in range(0, len(seq), 80):
                f.write(seq[j:j+80] + '\n')
    
    print(f"Created sample FASTA file: {filename}")


def create_compressed_fasta(filename: str, num_sequences: int = 50):
    """Create a compressed FASTA file."""
    with gzip.open(filename, 'wt') as f:
        for i in range(num_sequences):
            length = random.randint(500, 5000)
            seq = generate_random_sequence(length)
            header = f"compressed_seq_{i+1} length={length}"
            
            f.write(f">{header}\n")
            for j in range(0, len(seq), 80):
                f.write(seq[j:j+80] + '\n')
    
    print(f"Created compressed FASTA file: {filename}")


def main():
    print("=" * 70)
    print("FASTA PARSER DEMONSTRATION")
    print("=" * 70)
    
    # Create sample data
    print("\n1. Creating sample FASTA files...")
    create_sample_fasta('sample.fasta', num_sequences=100)
    create_compressed_fasta('sample_compressed.fasta.gz', num_sequences=50)
    
    # Parse uncompressed file
    print("\n2. Parsing uncompressed FASTA file...")
    fasta = FastaParser()
    fasta.parse('sample.fasta')
    print(f"   Loaded {len(fasta)} sequences")
    
    # Print statistics
    print("\n3. Printing statistics...")
    fasta.print_statistics()
    
    # Demonstrate sequence access
    print("\n4. Demonstrating sequence access...")
    print(f"   First sequence: {fasta[0]}")
    print(f"   Sequence details:")
    print(f"     - Header: {fasta[0].header}")
    print(f"     - ID: {fasta[0].id}")
    print(f"     - Length: {fasta[0].length:,} bp")
    print(f"     - GC Content: {fasta[0].gc_content:.2f}%")
    print(f"     - First 50 bp: {fasta[0].sequence[:50]}...")
    
    # Get sequence by ID
    print("\n5. Retrieving sequence by ID...")
    seq = fasta.get_sequence_by_id('chromosome_1')
    if seq:
        print(f"   Found: {seq}")
    
    # Filter sequences
    print("\n6. Filtering sequences (length >= 1000 bp)...")
    original_count = len(fasta)
    fasta.filter_by_length(min_length=1000)
    print(f"   Filtered from {original_count} to {len(fasta)} sequences")
    
    # Sort sequences
    print("\n7. Sorting sequences by length (descending)...")
    fasta.sort_sequences(key='length', reverse=True)
    print(f"   Top 5 longest sequences:")
    for i, seq in enumerate(fasta.sequences[:5]):
        print(f"     {i+1}. {seq.id}: {seq.length:,} bp")
    
    # Write sorted output
    print("\n8. Writing sorted sequences to file...")
    fasta.write('sample_sorted.fasta')
    fasta.write('sample_sorted_compressed.fasta.gz')  # Also write compressed
    print(f"   Written to: sample_sorted.fasta")
    print(f"   Written to: sample_sorted_compressed.fasta.gz")
    
    # Parse compressed file
    print("\n9. Parsing compressed FASTA file...")
    fasta_compressed = FastaParser()
    fasta_compressed.parse('sample_compressed.fasta.gz')
    print(f"   Loaded {len(fasta_compressed)} sequences from compressed file")
    
    # Sort by GC content
    print("\n10. Sorting by GC content...")
    fasta_compressed.sort_sequences(key='gc_content', reverse=True)
    print(f"    Top 5 sequences by GC content:")
    for i, seq in enumerate(fasta_compressed.sequences[:5]):
        print(f"      {i+1}. {seq.id}: {seq.gc_content:.2f}%")
    
    # Create visualizations
    print("\n11. Creating visualizations...")
    fasta.visualize(output_file='fasta_analysis.png')
    
    # Demonstrate iteration
    print("\n12. Demonstrating iteration over sequences...")
    total_bases = sum(seq.length for seq in fasta)
    print(f"    Total bases in filtered dataset: {total_bases:,}")
    
    # Show method chaining
    print("\n13. Demonstrating method chaining...")
    result = (FastaParser()
              .parse('sample.fasta')
              .filter_by_length(min_length=2000, max_length=10000)
              .sort_sequences(key='gc_content', reverse=False))
    print(f"    Chained operations resulted in {len(result)} sequences")
    result.print_statistics()
    
    print("\n" + "=" * 70)
    print("DEMONSTRATION COMPLETE!")
    print("=" * 70)
    print("\nGenerated files:")
    print("  - sample.fasta")
    print("  - sample_compressed.fasta.gz")
    print("  - sample_sorted.fasta")
    print("  - sample_sorted_compressed.fasta.gz")
    print("  - fasta_analysis.png")
    print("\nTry the command-line interface:")
    print("  python fasta_parser.py sample.fasta -o output.fasta -s length --visualize viz.png")


if __name__ == "__main__":
    # Set random seed for reproducibility
    random.seed(42)
    main()
