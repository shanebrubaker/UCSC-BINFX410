#!/usr/bin/env python3
"""
Real-world bioinformatics examples using the FASTA parser.
Demonstrates practical genomics analysis workflows.
"""

from fasta_parser import FastaParser
import sys


def assembly_quality_control(assembly_file: str):
    """
    Perform quality control on a genome assembly.
    Reports assembly statistics and identifies potential issues.
    """
    print("\n" + "="*70)
    print("ASSEMBLY QUALITY CONTROL REPORT")
    print("="*70)
    
    fasta = FastaParser().parse(assembly_file)
    
    # Basic statistics
    fasta.print_statistics()
    
    # Check for potential issues
    print("\nQUALITY CHECKS:")
    
    # 1. Check for very short contigs
    short_contigs = [s for s in fasta if s.length < 500]
    if short_contigs:
        print(f"⚠ WARNING: {len(short_contigs)} contigs < 500 bp")
        print(f"  Consider filtering these out")
    else:
        print(f"✓ No contigs < 500 bp")
    
    # 2. Check for extreme GC content (potential contamination)
    extreme_gc = [s for s in fasta if s.gc_content < 20 or s.gc_content > 80]
    if extreme_gc:
        print(f"⚠ WARNING: {len(extreme_gc)} sequences with extreme GC content")
        print(f"  Possible contamination or unusual sequences:")
        for seq in extreme_gc[:5]:
            print(f"    - {seq.id}: {seq.gc_content:.1f}% GC, {seq.length} bp")
    else:
        print(f"✓ All sequences have reasonable GC content")
    
    # 3. Assembly fragmentation
    if len(fasta) > 1000:
        print(f"⚠ INFO: Assembly is highly fragmented ({len(fasta)} sequences)")
    else:
        print(f"✓ Assembly fragmentation is reasonable ({len(fasta)} sequences)")
    
    # 4. N50 assessment
    lengths = [s.length for s in fasta]
    n50 = fasta._calculate_n50(lengths)
    if n50 < 1000:
        print(f"⚠ WARNING: Low N50 ({n50:,} bp) suggests poor assembly quality")
    else:
        print(f"✓ N50 is {n50:,} bp")
    
    # Generate QC report
    fasta.visualize(f"{assembly_file}_QC_report.png")
    print(f"\n📊 Visual QC report saved to: {assembly_file}_QC_report.png")


def extract_long_sequences(input_file: str, min_length: int = 10000, 
                          output_file: str = "long_sequences.fasta"):
    """
    Extract sequences longer than a threshold (useful for scaffolding).
    """
    print(f"\nExtracting sequences >= {min_length:,} bp from {input_file}")
    
    fasta = (FastaParser()
             .parse(input_file)
             .filter_by_length(min_length=min_length)
             .sort_sequences(key='length', reverse=True))
    
    if len(fasta) == 0:
        print(f"⚠ No sequences found >= {min_length:,} bp")
        return
    
    fasta.write(output_file)
    
    print(f"✓ Extracted {len(fasta)} sequences")
    print(f"  Longest: {fasta[0].length:,} bp")
    print(f"  Shortest: {fasta[-1].length:,} bp")
    print(f"  Total bases: {sum(s.length for s in fasta):,} bp")
    print(f"  Saved to: {output_file}")


def compare_assemblies(file1: str, file2: str):
    """
    Compare two assemblies (e.g., before and after scaffolding).
    """
    print("\n" + "="*70)
    print("ASSEMBLY COMPARISON")
    print("="*70)
    
    print(f"\nAssembly 1: {file1}")
    fasta1 = FastaParser().parse(file1)
    lengths1 = [s.length for s in fasta1]
    n50_1 = fasta1._calculate_n50(lengths1)
    
    print(f"  Sequences: {len(fasta1):,}")
    print(f"  Total bases: {sum(lengths1):,}")
    print(f"  N50: {n50_1:,} bp")
    print(f"  Longest: {max(lengths1):,} bp")
    
    print(f"\nAssembly 2: {file2}")
    fasta2 = FastaParser().parse(file2)
    lengths2 = [s.length for s in fasta2]
    n50_2 = fasta2._calculate_n50(lengths2)
    
    print(f"  Sequences: {len(fasta2):,}")
    print(f"  Total bases: {sum(lengths2):,}")
    print(f"  N50: {n50_2:,} bp")
    print(f"  Longest: {max(lengths2):,} bp")
    
    print("\nIMPROVEMENT METRICS:")
    seq_reduction = ((len(fasta1) - len(fasta2)) / len(fasta1)) * 100
    n50_improvement = ((n50_2 - n50_1) / n50_1) * 100
    
    print(f"  Sequence reduction: {seq_reduction:.1f}%")
    print(f"  N50 improvement: {n50_improvement:+.1f}%")


def identify_outliers(input_file: str):
    """
    Identify sequences that are outliers in length or GC content.
    Useful for detecting contamination or misassemblies.
    """
    print("\n" + "="*70)
    print("OUTLIER DETECTION")
    print("="*70)
    
    fasta = FastaParser().parse(input_file)
    
    import numpy as np
    lengths = [s.length for s in fasta]
    gc_contents = [s.gc_content for s in fasta]
    
    # Calculate Z-scores for length
    mean_len = np.mean(lengths)
    std_len = np.std(lengths)
    
    print(f"\nLENGTH OUTLIERS (|Z-score| > 3):")
    length_outliers = []
    for seq in fasta:
        z_score = (seq.length - mean_len) / std_len
        if abs(z_score) > 3:
            length_outliers.append((seq, z_score))
    
    if length_outliers:
        length_outliers.sort(key=lambda x: abs(x[1]), reverse=True)
        for seq, z in length_outliers[:10]:
            print(f"  {seq.id}: {seq.length:,} bp (Z={z:+.2f})")
    else:
        print("  No significant length outliers detected")
    
    # GC content outliers
    mean_gc = np.mean(gc_contents)
    std_gc = np.std(gc_contents)
    
    print(f"\nGC CONTENT OUTLIERS (|Z-score| > 3):")
    gc_outliers = []
    for seq in fasta:
        z_score = (seq.gc_content - mean_gc) / std_gc
        if abs(z_score) > 3:
            gc_outliers.append((seq, z_score))
    
    if gc_outliers:
        gc_outliers.sort(key=lambda x: abs(x[1]), reverse=True)
        for seq, z in gc_outliers[:10]:
            print(f"  {seq.id}: {seq.gc_content:.1f}% GC (Z={z:+.2f})")
    else:
        print("  No significant GC content outliers detected")


def create_size_selected_libraries(input_file: str):
    """
    Create size-selected sequence libraries (common in genomics).
    """
    print("\n" + "="*70)
    print("SIZE-SELECTED LIBRARY CREATION")
    print("="*70)
    
    fasta = FastaParser().parse(input_file)
    
    # Define size bins
    bins = [
        (0, 1000, "short"),
        (1000, 5000, "medium"),
        (5000, 20000, "long"),
        (20000, float('inf'), "very_long")
    ]
    
    for min_len, max_len, name in bins:
        filtered = FastaParser().parse(input_file)
        filtered.filter_by_length(min_length=min_len, max_length=max_len)
        
        if len(filtered) > 0:
            output_file = f"{name}_fragments.fasta"
            filtered.write(output_file)
            
            print(f"\n{name.upper()} ({min_len:,}-{max_len:,} bp):")
            print(f"  Sequences: {len(filtered):,}")
            print(f"  Total bases: {sum(s.length for s in filtered):,}")
            print(f"  Saved to: {output_file}")


def main():
    """Demonstrate real-world bioinformatics workflows."""
    
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
    else:
        # Use demo file
        print("No input file provided. Using sample.fasta from demo.")
        input_file = "sample.fasta"
        
        # Run demo if sample doesn't exist
        if not __import__('pathlib').Path(input_file).exists():
            print("Running demo to create sample data...")
            import demo_fasta_parser
            demo_fasta_parser.main()
    
    print("\n" + "#"*70)
    print("# FASTA PARSER - REAL-WORLD BIOINFORMATICS EXAMPLES")
    print("#"*70)
    
    # Run all analyses
    assembly_quality_control(input_file)
    
    extract_long_sequences(input_file, min_length=5000, 
                          output_file="scaffolds.fasta")
    
    identify_outliers(input_file)
    
    create_size_selected_libraries(input_file)
    
    print("\n" + "="*70)
    print("ANALYSIS COMPLETE!")
    print("="*70)


if __name__ == "__main__":
    main()
