# Comprehensive FASTA Parser

A full-featured Python FASTA file parser with support for compressed files, sequence analysis, visualization, and sorting capabilities.

## Features

### 📁 File Handling
- **Compressed file support**: Automatically handles `.gz` (gzip) and `.bz2` (bzip2) compressed files
- **Automatic format detection**: Detects compression based on file extension
- **Write capabilities**: Export sequences in sorted order with optional compression

### 🔍 Sequence Analysis
- **Statistics calculation**: Comprehensive sequence statistics including:
  - Length statistics (min, max, mean, median, std dev)
  - N50 calculation
  - GC content analysis
  - Base composition breakdown
- **Filtering**: Filter sequences by length range
- **Sorting**: Sort by multiple criteria (length, ID, GC content, header)

### 📊 Visualization
Six comprehensive plots showing:
1. **Sequence Length Distribution** - Histogram of sequence sizes
2. **GC Content Distribution** - Distribution of GC percentages
3. **Length vs GC Content** - Scatter plot showing correlation
4. **Cumulative Sequence Length** - Cumulative length curve
5. **Base Composition** - Pie chart of A, T, G, C proportions
6. **Top 10 Longest Sequences** - Bar chart of longest sequences

### 💾 Data Storage
- **Object-oriented design**: Clean `FastaSequence` class for each sequence
- **Efficient access**: Index-based and ID-based sequence retrieval
- **Iterable**: Supports standard Python iteration
- **Method chaining**: Fluent interface for operations

## Installation

### Requirements
```bash
pip install matplotlib numpy seaborn --break-system-packages
```

### Files
- `fasta_parser.py` - Main parser module
- `demo_fasta_parser.py` - Demonstration script
- `FASTA_Parser_Tutorial.ipynb` - Interactive Jupyter notebook tutorial

## Getting Started

### Interactive Tutorial (Recommended)
The easiest way to get started is with the Jupyter notebook:
```bash
jupyter notebook FASTA_Parser_Tutorial.ipynb
```

The notebook includes:
- Step-by-step examples
- Interactive visualizations
- Real-world workflows
- Comprehensive coverage of all features

### Command-Line Usage

Basic usage:
```bash
python fasta_parser.py input.fasta
```

Full options:
```bash
python fasta_parser.py input.fasta \
    -o output_sorted.fasta \
    -s length \
    --ascending \
    -v visualization.png \
    --min-length 1000 \
    --max-length 50000
```

#### Arguments:
- `input` - Input FASTA file (required, can be compressed)
- `-o, --output` - Output file for sorted sequences
- `-s, --sort` - Sort key: `length`, `id`, `gc_content`, or `header` (default: length)
- `--ascending` - Sort in ascending order (default: descending)
- `-v, --visualize` - Save visualization to specified file
- `--min-length` - Minimum sequence length filter
- `--max-length` - Maximum sequence length filter

### Python API

#### Basic Usage

```python
from fasta_parser import FastaParser

# Parse a FASTA file
fasta = FastaParser()
fasta.parse('myfile.fasta')

# Print statistics
fasta.print_statistics()

# Create visualizations
fasta.visualize(output_file='analysis.png')
```

#### Working with Compressed Files

```python
# Parse gzipped file
fasta = FastaParser()
fasta.parse('sequences.fasta.gz')

# Write compressed output
fasta.write('output.fasta.gz')
```

#### Filtering and Sorting

```python
# Filter by length
fasta.filter_by_length(min_length=1000, max_length=10000)

# Sort by different criteria
fasta.sort_sequences(key='length', reverse=True)  # Longest first
fasta.sort_sequences(key='gc_content', reverse=False)  # Lowest GC first
fasta.sort_sequences(key='id')  # Alphabetically by ID
```

#### Accessing Sequences

```python
# By index
first_seq = fasta[0]
print(f"Length: {first_seq.length}")
print(f"GC: {first_seq.gc_content}%")

# By ID
seq = fasta.get_sequence_by_id('chromosome_1')

# Iteration
for seq in fasta:
    print(f"{seq.id}: {seq.length} bp")
```

#### Method Chaining

```python
result = (FastaParser()
    .parse('input.fasta')
    .filter_by_length(min_length=2000)
    .sort_sequences(key='gc_content'))

result.write('filtered_sorted.fasta')
```

### FastaSequence Class

Each sequence is stored as a `FastaSequence` object with properties:

```python
seq = fasta[0]

# Properties
seq.header       # Full header line (without '>')
seq.id          # First word of header
seq.sequence    # DNA/RNA sequence string
seq.length      # Sequence length
seq.gc_content  # GC percentage (calculated)
```

## Examples

### Example 1: Quick Statistics

```python
from fasta_parser import FastaParser

fasta = FastaParser().parse('genome.fasta')
fasta.print_statistics()
```

Output:
```
======================================================================
FASTA FILE STATISTICS: genome.fasta
======================================================================

General Statistics:
  Total sequences:        100
  Total bases:            253,327

Sequence Length Statistics:
  Minimum length:         119 bp
  Maximum length:         19,956 bp
  Mean length:            2,533.27 bp
  Median length:          741.50 bp
  Std deviation:          4,828.81 bp
  N50:                    15,476 bp

GC Content Statistics:
  Minimum GC%:            41.52%
  Maximum GC%:            57.14%
  Mean GC%:               49.97%
  Median GC%:             50.19%

Base Composition:
  A:                      63,591 (25.10%)
  T:                      63,216 (24.95%)
  G:                      63,094 (24.91%)
  C:                      63,426 (25.04%)
  N:                      0 (0.00%)
======================================================================
```

### Example 2: Filter and Sort

```python
from fasta_parser import FastaParser

# Load and filter
fasta = FastaParser()
fasta.parse('contigs.fasta.gz')
fasta.filter_by_length(min_length=5000)

# Sort by GC content
fasta.sort_sequences(key='gc_content', reverse=True)

# Save results
fasta.write('high_gc_long_contigs.fasta')

# Show top 5
for seq in fasta[:5]:
    print(f"{seq.id}: {seq.length} bp, GC={seq.gc_content:.1f}%")
```

### Example 3: Analysis Pipeline

```python
from fasta_parser import FastaParser

# Complete analysis pipeline
(FastaParser()
    .parse('raw_sequences.fasta.gz')
    .filter_by_length(min_length=1000, max_length=50000)
    .sort_sequences(key='length', reverse=True)
    .write('filtered_sorted.fasta')
    .visualize('analysis.png'))
```

### Example 4: Custom Analysis

```python
from fasta_parser import FastaParser

fasta = FastaParser().parse('genes.fasta')

# Calculate average GC content
avg_gc = sum(seq.gc_content for seq in fasta) / len(fasta)
print(f"Average GC content: {avg_gc:.2f}%")

# Find sequences with extreme GC content
high_gc = [seq for seq in fasta if seq.gc_content > 60]
low_gc = [seq for seq in fasta if seq.gc_content < 40]

print(f"High GC sequences (>60%): {len(high_gc)}")
print(f"Low GC sequences (<40%): {len(low_gc)}")

# Find longest sequence
longest = max(fasta.sequences, key=lambda s: s.length)
print(f"Longest: {longest.id} ({longest.length:,} bp)")
```

## Visualization Output

The `visualize()` method creates a comprehensive 6-panel figure:

1. **Top-left**: Sequence length distribution histogram
2. **Top-middle**: GC content distribution histogram  
3. **Top-right**: Length vs GC content scatter plot
4. **Bottom-left**: Cumulative sequence length curve
5. **Bottom-middle**: Base composition pie chart
6. **Bottom-right**: Top 10 longest sequences bar chart

All visualizations are publication-quality with 300 DPI output.

## Performance Notes

- Efficient memory usage with generator-based parsing
- Handles large files (tested up to several GB)
- Compressed file reading adds minimal overhead
- Sorting is in-memory (consider chunking for huge files)

## File Format Support

### Input Formats
- `.fasta`, `.fa`, `.fna`, `.ffn` - Uncompressed FASTA
- `.fasta.gz`, `.fa.gz` - Gzip compressed
- `.fasta.bz2`, `.fa.bz2` - Bzip2 compressed

### Output Formats
- Same as input formats
- Automatic compression based on file extension

## Common Use Cases

### Quality Control
```python
fasta = FastaParser().parse('assembly.fasta')
fasta.print_statistics()
fasta.visualize('qc_report.png')
```

### Pre-processing
```python
# Remove short sequences and sort
(FastaParser()
    .parse('raw.fasta')
    .filter_by_length(min_length=500)
    .sort_sequences(key='length', reverse=True)
    .write('processed.fasta'))
```

### Data Exploration
```python
fasta = FastaParser().parse('unknown.fasta')
print(f"Number of sequences: {len(fasta)}")
print(f"Total size: {sum(s.length for s in fasta):,} bp")
print(f"Average length: {sum(s.length for s in fasta) / len(fasta):.0f} bp")
```

## Error Handling

The parser handles common issues:
- Empty files
- Malformed headers
- Missing sequences
- Compression format detection
- Invalid file paths

## Testing

Run the demonstration script to test all features:
```bash
python demo_fasta_parser.py
```

This will:
1. Generate sample FASTA files
2. Demonstrate all parser features
3. Create visualizations
4. Show statistics
5. Test compressed file handling

## License

This code is provided as-is for bioinformatics research and education.

## Author

Created for comprehensive FASTA file analysis in genomics workflows.
