#!/usr/bin/env python3
"""
Comprehensive FASTA Parser with support for:
- Compressed/uncompressed files (gzip, bzip2)
- Storage and retrieval of sequences
- Sorting and writing output
- Visualizations
- Summary statistics
"""

import gzip
import bz2
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Union
from dataclasses import dataclass
import matplotlib.pyplot as plt
import numpy as np
from collections import Counter
import seaborn as sns


@dataclass
class FastaSequence:
    """Data class to store a FASTA sequence with metadata."""
    header: str
    sequence: str
    
    @property
    def id(self) -> str:
        """Extract sequence ID (first word of header)."""
        return self.header.split()[0]
    
    @property
    def length(self) -> int:
        """Return sequence length."""
        return len(self.sequence)
    
    @property
    def gc_content(self) -> float:
        """Calculate GC content percentage."""
        if self.length == 0:
            return 0.0
        gc_count = self.sequence.upper().count('G') + self.sequence.upper().count('C')
        return (gc_count / self.length) * 100
    
    def __repr__(self) -> str:
        return f"FastaSequence(id='{self.id}', length={self.length})"


class FastaParser:
    """
    A comprehensive FASTA file parser with visualization and analysis capabilities.
    """
    
    def __init__(self):
        self.sequences: List[FastaSequence] = []
        self.filename: Optional[str] = None
    
    def _open_file(self, filepath: Union[str, Path]):
        """
        Open a file handle, automatically detecting compression.
        
        Args:
            filepath: Path to the FASTA file
            
        Returns:
            File handle (text mode)
        """
        filepath = Path(filepath)
        
        if filepath.suffix == '.gz':
            return gzip.open(filepath, 'rt')
        elif filepath.suffix in ['.bz2', '.bzip2']:
            return bz2.open(filepath, 'rt')
        else:
            return open(filepath, 'r')
    
    def parse(self, filepath: Union[str, Path]) -> 'FastaParser':
        """
        Parse a FASTA file (compressed or uncompressed).
        
        Args:
            filepath: Path to the FASTA file
            
        Returns:
            Self for method chaining
        """
        self.filename = str(filepath)
        self.sequences = []
        
        current_header = None
        current_sequence = []
        
        with self._open_file(filepath) as f:
            for line in f:
                line = line.strip()
                
                if not line:  # Skip empty lines
                    continue
                
                if line.startswith('>'):
                    # Save previous sequence if it exists
                    if current_header is not None:
                        self.sequences.append(
                            FastaSequence(
                                header=current_header,
                                sequence=''.join(current_sequence)
                            )
                        )
                    
                    # Start new sequence
                    current_header = line[1:]  # Remove '>'
                    current_sequence = []
                else:
                    current_sequence.append(line)
            
            # Don't forget the last sequence
            if current_header is not None:
                self.sequences.append(
                    FastaSequence(
                        header=current_header,
                        sequence=''.join(current_sequence)
                    )
                )
        
        return self
    
    def sort_sequences(self, key: str = 'length', reverse: bool = True) -> 'FastaParser':
        """
        Sort sequences by various criteria.
        
        Args:
            key: Sort key ('length', 'id', 'gc_content', 'header')
            reverse: Sort in descending order if True
            
        Returns:
            Self for method chaining
        """
        if key == 'length':
            self.sequences.sort(key=lambda x: x.length, reverse=reverse)
        elif key == 'id':
            self.sequences.sort(key=lambda x: x.id, reverse=reverse)
        elif key == 'gc_content':
            self.sequences.sort(key=lambda x: x.gc_content, reverse=reverse)
        elif key == 'header':
            self.sequences.sort(key=lambda x: x.header, reverse=reverse)
        else:
            raise ValueError(f"Unknown sort key: {key}")
        
        return self
    
    def write(self, filepath: Union[str, Path], width: int = 80) -> None:
        """
        Write sequences to a FASTA file.
        
        Args:
            filepath: Output file path
            width: Line width for sequence wrapping (0 = no wrapping)
        """
        filepath = Path(filepath)
        
        # Determine if we should compress based on extension
        if filepath.suffix == '.gz':
            fh = gzip.open(filepath, 'wt')
        elif filepath.suffix in ['.bz2', '.bzip2']:
            fh = bz2.open(filepath, 'wt')
        else:
            fh = open(filepath, 'w')
        
        try:
            for seq in self.sequences:
                fh.write(f">{seq.header}\n")
                
                if width > 0:
                    # Wrap sequence to specified width
                    for i in range(0, len(seq.sequence), width):
                        fh.write(seq.sequence[i:i+width] + '\n')
                else:
                    fh.write(seq.sequence + '\n')
        finally:
            fh.close()
    
    def print_statistics(self) -> None:
        """Print comprehensive statistics about the FASTA file."""
        if not self.sequences:
            print("No sequences loaded.")
            return
        
        lengths = [seq.length for seq in self.sequences]
        gc_contents = [seq.gc_content for seq in self.sequences]
        
        print("=" * 70)
        print(f"FASTA FILE STATISTICS: {self.filename or 'In-memory sequences'}")
        print("=" * 70)
        print(f"\nGeneral Statistics:")
        print(f"  Total sequences:        {len(self.sequences):,}")
        print(f"  Total bases:            {sum(lengths):,}")
        
        print(f"\nSequence Length Statistics:")
        print(f"  Minimum length:         {min(lengths):,} bp")
        print(f"  Maximum length:         {max(lengths):,} bp")
        print(f"  Mean length:            {np.mean(lengths):,.2f} bp")
        print(f"  Median length:          {np.median(lengths):,.2f} bp")
        print(f"  Std deviation:          {np.std(lengths):,.2f} bp")
        
        # Calculate N50
        n50 = self._calculate_n50(lengths)
        print(f"  N50:                    {n50:,} bp")
        
        print(f"\nGC Content Statistics:")
        print(f"  Minimum GC%:            {min(gc_contents):.2f}%")
        print(f"  Maximum GC%:            {max(gc_contents):.2f}%")
        print(f"  Mean GC%:               {np.mean(gc_contents):.2f}%")
        print(f"  Median GC%:             {np.median(gc_contents):.2f}%")
        
        # Base composition
        all_seq = ''.join(seq.sequence.upper() for seq in self.sequences)
        base_counts = Counter(all_seq)
        
        print(f"\nBase Composition:")
        for base in ['A', 'T', 'G', 'C', 'N']:
            count = base_counts.get(base, 0)
            pct = (count / len(all_seq) * 100) if all_seq else 0
            print(f"  {base}:                      {count:,} ({pct:.2f}%)")
        
        other_bases = sum(v for k, v in base_counts.items() if k not in 'ATGCN')
        if other_bases > 0:
            pct = (other_bases / len(all_seq) * 100) if all_seq else 0
            print(f"  Other:                  {other_bases:,} ({pct:.2f}%)")
        
        print("=" * 70)
    
    def _calculate_n50(self, lengths: List[int]) -> int:
        """Calculate N50 statistic."""
        sorted_lengths = sorted(lengths, reverse=True)
        total_length = sum(sorted_lengths)
        cumsum = 0
        
        for length in sorted_lengths:
            cumsum += length
            if cumsum >= total_length / 2:
                return length
        return 0
    
    def visualize(self, output_file: Optional[str] = None, figsize: Tuple[int, int] = (16, 10)) -> None:
        """
        Create comprehensive visualizations of FASTA file contents.
        
        Args:
            output_file: Optional path to save the figure
            figsize: Figure size as (width, height)
        """
        if not self.sequences:
            print("No sequences to visualize.")
            return
        
        # Set style
        sns.set_style("whitegrid")
        
        # Create figure with subplots
        fig, axes = plt.subplots(2, 3, figsize=figsize)
        fig.suptitle(f'FASTA File Analysis: {self.filename or "In-memory"}', 
                     fontsize=16, fontweight='bold')
        
        lengths = [seq.length for seq in self.sequences]
        gc_contents = [seq.gc_content for seq in self.sequences]
        
        # 1. Sequence Length Distribution (Histogram)
        ax1 = axes[0, 0]
        ax1.hist(lengths, bins=min(50, len(self.sequences)), 
                 color='steelblue', edgecolor='black', alpha=0.7)
        ax1.set_xlabel('Sequence Length (bp)', fontsize=10)
        ax1.set_ylabel('Frequency', fontsize=10)
        ax1.set_title('Sequence Length Distribution', fontweight='bold')
        ax1.grid(alpha=0.3)
        
        # 2. GC Content Distribution
        ax2 = axes[0, 1]
        ax2.hist(gc_contents, bins=min(50, len(self.sequences)), 
                 color='seagreen', edgecolor='black', alpha=0.7)
        ax2.set_xlabel('GC Content (%)', fontsize=10)
        ax2.set_ylabel('Frequency', fontsize=10)
        ax2.set_title('GC Content Distribution', fontweight='bold')
        ax2.grid(alpha=0.3)
        
        # 3. Length vs GC Content Scatter
        ax3 = axes[0, 2]
        ax3.scatter(lengths, gc_contents, alpha=0.5, c='coral', edgecolors='black', s=50)
        ax3.set_xlabel('Sequence Length (bp)', fontsize=10)
        ax3.set_ylabel('GC Content (%)', fontsize=10)
        ax3.set_title('Length vs GC Content', fontweight='bold')
        ax3.grid(alpha=0.3)
        
        # 4. Cumulative Length Distribution
        ax4 = axes[1, 0]
        sorted_lengths = sorted(lengths, reverse=True)
        cumsum = np.cumsum(sorted_lengths)
        ax4.plot(range(len(cumsum)), cumsum / 1e6, color='purple', linewidth=2)
        ax4.set_xlabel('Sequence Rank', fontsize=10)
        ax4.set_ylabel('Cumulative Length (Mb)', fontsize=10)
        ax4.set_title('Cumulative Sequence Length', fontweight='bold')
        ax4.grid(alpha=0.3)
        
        # 5. Base Composition (Pie Chart)
        ax5 = axes[1, 1]
        all_seq = ''.join(seq.sequence.upper() for seq in self.sequences)
        base_counts = Counter(all_seq)
        
        bases = ['A', 'T', 'G', 'C']
        counts = [base_counts.get(base, 0) for base in bases]
        colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A']
        
        ax5.pie(counts, labels=bases, autopct='%1.1f%%', 
                colors=colors, startangle=90)
        ax5.set_title('Base Composition', fontweight='bold')
        
        # 6. Top 10 Longest Sequences
        ax6 = axes[1, 2]
        top_10 = sorted(self.sequences, key=lambda x: x.length, reverse=True)[:10]
        y_pos = np.arange(len(top_10))
        seq_lengths = [seq.length for seq in top_10]
        seq_ids = [seq.id[:20] + '...' if len(seq.id) > 20 else seq.id 
                   for seq in top_10]
        
        ax6.barh(y_pos, seq_lengths, color='indianred', edgecolor='black')
        ax6.set_yticks(y_pos)
        ax6.set_yticklabels(seq_ids, fontsize=8)
        ax6.set_xlabel('Length (bp)', fontsize=10)
        ax6.set_title('Top 10 Longest Sequences', fontweight='bold')
        ax6.invert_yaxis()
        ax6.grid(axis='x', alpha=0.3)
        
        plt.tight_layout()
        
        if output_file:
            plt.savefig(output_file, dpi=300, bbox_inches='tight')
            print(f"Visualization saved to: {output_file}")
        
        plt.show()
    
    def get_sequence_by_id(self, seq_id: str) -> Optional[FastaSequence]:
        """
        Retrieve a sequence by its ID.
        
        Args:
            seq_id: Sequence ID to search for
            
        Returns:
            FastaSequence if found, None otherwise
        """
        for seq in self.sequences:
            if seq.id == seq_id:
                return seq
        return None
    
    def filter_by_length(self, min_length: int = 0, max_length: int = float('inf')) -> 'FastaParser':
        """
        Filter sequences by length range.
        
        Args:
            min_length: Minimum sequence length
            max_length: Maximum sequence length
            
        Returns:
            Self for method chaining
        """
        self.sequences = [seq for seq in self.sequences 
                         if min_length <= seq.length <= max_length]
        return self
    
    def __len__(self) -> int:
        """Return number of sequences."""
        return len(self.sequences)
    
    def __getitem__(self, index: int) -> FastaSequence:
        """Get sequence by index."""
        return self.sequences[index]
    
    def __iter__(self):
        """Make the parser iterable."""
        return iter(self.sequences)


# Example usage and demonstration
if __name__ == "__main__":
    import argparse
    
    parser_cli = argparse.ArgumentParser(
        description="Comprehensive FASTA file parser and analyzer"
    )
    parser_cli.add_argument('input', help='Input FASTA file (can be .gz or .bz2)')
    parser_cli.add_argument('-o', '--output', help='Output FASTA file (sorted)')
    parser_cli.add_argument('-s', '--sort', choices=['length', 'id', 'gc_content', 'header'],
                           default='length', help='Sort key (default: length)')
    parser_cli.add_argument('--ascending', action='store_true', 
                           help='Sort in ascending order (default: descending)')
    parser_cli.add_argument('-v', '--visualize', help='Save visualization to file')
    parser_cli.add_argument('--min-length', type=int, default=0,
                           help='Minimum sequence length filter')
    parser_cli.add_argument('--max-length', type=int, default=float('inf'),
                           help='Maximum sequence length filter')
    
    args = parser_cli.parse_args()
    
    # Parse FASTA file
    print(f"Parsing FASTA file: {args.input}")
    fasta = FastaParser()
    fasta.parse(args.input)
    
    # Apply filters
    if args.min_length > 0 or args.max_length < float('inf'):
        print(f"Filtering sequences: {args.min_length} <= length <= {args.max_length}")
        fasta.filter_by_length(args.min_length, args.max_length)
    
    # Print statistics
    fasta.print_statistics()
    
    # Sort if requested
    if args.output:
        fasta.sort_sequences(key=args.sort, reverse=not args.ascending)
        print(f"\nWriting sorted sequences to: {args.output}")
        fasta.write(args.output)
    
    # Visualize if requested
    if args.visualize:
        print(f"\nGenerating visualizations...")
        fasta.visualize(output_file=args.visualize)
